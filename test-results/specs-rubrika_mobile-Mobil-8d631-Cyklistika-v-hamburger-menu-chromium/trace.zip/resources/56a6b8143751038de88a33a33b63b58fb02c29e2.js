(function ($) {
    var $trigger = $('[data-trigger="load-more"]'),
        displayTrigger;

    $trigger.on('click', function () {
        var $wrapper = $(this).closest('[data-load-more-wrapper]'),
            $container = $('[data-load-more-container]', $wrapper),
            offset = $wrapper.data('offset'),
            limit = $wrapper.data('limit'),
            totalCount = $wrapper.data('total-count'),
            newOffset = offset + limit;

        if (totalCount <= newOffset + limit) {
            $trigger.hide();
        }

        $wrapper.data('offset', newOffset);

        $.ajax({
            url: $wrapper.data('url'),
            data: {
                'offset': newOffset,
                'limit': limit
            },
            success: function (data) {
                // console.log('success', data);
                $container.append(data);

                var myLazyLoad = new LazyLoad({
                    elements_selector: ".lazy-image",
                    callback_set: function () {
                        picturefill({reevaluate: true});

                        if (CTCOMP) {
                            CTCOMP.init($container);
                        }
                    }
                });
            }
        });

        displayTrigger = function () {

        }

    })
})(jQuery);
